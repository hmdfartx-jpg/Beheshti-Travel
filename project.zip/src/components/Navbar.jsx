import React, { useState } from 'react';
import { Plane, Menu, X } from 'lucide-react'; // آیکون‌ها را ایمپورت کنید

export default function Navbar({ lang, setLang, page, setPage, t }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white border-b sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
        {/* لوگو */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setPage('home')}>
          <div className="w-12 h-12 bg-[#058B8C] rounded-xl flex items-center justify-center text-white shadow-lg">
            <Plane size={28} />
          </div>
          <div>
            <h1 className="font-black text-xl text-[#058B8C] leading-none">{t.title}</h1>
            <p className="text-[10px] text-gray-400 font-bold mt-1 tracking-widest uppercase">Kabul Office</p>
          </div>
        </div>

        {/* منوی دسکتاپ */}
        <div className="hidden lg:flex items-center gap-6 font-bold text-gray-600">
          {Object.entries(t.nav).map(([key, val]) => (
            <button 
              key={key} 
              onClick={() => setPage(key)} 
              className={`hover:text-[#058B8C] transition-colors ${page === key ? 'text-[#058B8C]' : ''}`}
            >
              {val}
            </button>
          ))}
          <div className="flex bg-gray-100 rounded-full p-1 ml-4">
            <button onClick={() => setLang('dr')} className={`px-4 py-1 rounded-full text-xs transition ${lang === 'dr' ? 'bg-[#058B8C] text-white shadow' : ''}`}>دری</button>
            <button onClick={() => setLang('ps')} className={`px-4 py-1 rounded-full text-xs transition ${lang === 'ps' ? 'bg-[#058B8C] text-white shadow' : ''}`}>پښتو</button>
          </div>
        </div>

        {/* منوی موبایل */}
        <button className="lg:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X /> : <Menu />}
        </button>
      </div>
      
      {/* دراپ‌داون موبایل */}
      {isMenuOpen && (
        <div className="lg:hidden bg-white border-t p-4 flex flex-col gap-4 animate-in slide-in-from-top">
          {Object.entries(t.nav).map(([key, val]) => (
            <button key={key} onClick={() => {setPage(key); setIsMenuOpen(false)}} className="text-right py-2 border-b border-gray-50">{val}</button>
          ))}
          <div className="flex justify-center gap-4 pt-2">
            <button onClick={() => setLang('dr')} className={lang === 'dr' ? 'text-[#058B8C] font-bold' : ''}>دری</button>
            <button onClick={() => setLang('ps')} className={lang === 'ps' ? 'text-[#058B8C] font-bold' : ''}>پښتو</button>
          </div>
        </div>
      )}
    </nav>
  );
}