import React from 'react';
import { Plane, MessageCircle, Globe, MapPin, Search } from 'lucide-react';

export default function Footer({ t, lang }) {
  return (
    <footer className="bg-[#058B8C] text-white mt-32 py-20 rounded-t-[5rem]">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-20">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white text-[#058B8C] rounded-2xl flex items-center justify-center shadow-xl">
              <Plane size={28} />
            </div>
            <h2 className="text-3xl font-black">{t.title}</h2>
          </div>
          <p className="opacity-70 leading-relaxed font-light">{t.subtitle}</p>
          <div className="flex gap-4">
             <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-white/20 cursor-pointer transition-colors"><MessageCircle size={20}/></div>
             <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center hover:bg-white/20 cursor-pointer transition-colors"><Globe size={20}/></div>
          </div>
        </div>

        <div className="space-y-6">
          <h4 className="text-xl font-black border-b border-white/10 pb-4">{t.nav.tickets || "خدمات"}</h4>
          <ul className="space-y-4 opacity-70 font-bold">
            <li className="hover:translate-x-[-10px] transition-transform cursor-pointer">ویزای شینگن و منطقه‌ای</li>
            <li className="hover:translate-x-[-10px] transition-transform cursor-pointer">بلیط چارتر و سیستمی</li>
            <li className="hover:translate-x-[-10px] transition-transform cursor-pointer">بورسیه‌های تحصیلی فول فاند</li>
            <li className="hover:translate-x-[-10px] transition-transform cursor-pointer">کارگو و حمل و نقل بین‌المللی</li>
          </ul>
        </div>
        
        <div className="space-y-6">
          <h4 className="text-xl font-black border-b border-white/10 pb-4">{lang === 'dr' ? "ارتباط با ما" : "له موږ سره اړیکه"}</h4>
          <div className="bg-white/10 p-8 rounded-[2.5rem] space-y-4">
            <div className="flex items-center gap-4">
              <MapPin className="text-[#D4AF37]" />
              <p className="text-sm">کابل، شهرنو، چهارراهی انصاری</p>
            </div>
            <div className="flex items-center gap-4">
              <Search className="text-[#D4AF37]" />
              <p className="text-lg font-black" dir="ltr">+93 700 000 000</p>
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 border-t border-white/10 mt-20 pt-10 text-center opacity-40 text-xs font-bold tracking-widest uppercase">
        © {new Date().getFullYear()} Beheshti Travel Agency. Managed in Kabul, Afghanistan.
      </div>
    </footer>
  );
}