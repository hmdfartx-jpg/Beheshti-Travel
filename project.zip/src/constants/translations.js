// رنگ‌ها
export const PRIMARY_COLOR = '#058B8C';
export const ACCENT_GOLD = '#D4AF37';

// ترجمه‌ها
export const translations = {
  dr: {
    title: "بهشتی تراول اجنسی",
    subtitle: "نماینده معتبر خدمات مسافرتی و تحصیلی در کابل",
    nav: { home: "صفحه اصلی", visa: "ویزای کشورها", tickets: "رزرو بلیط", scholarship: "بورسیه", cargo: "کارگو", tracking: "پیگیری", admin: "مدیریت" },
    home: {
      hero_title: "سفر آگاهانه، آینده درخشان",
      hero_sub: "از کابل تا دورترین نقاط جهان، ما همراه شما هستیم.",
      why_us: "چرا بهشتی تراول؟",
      why_desc: "تضمین امنیت، سرعت در صدور ویزا و شفافیت در هزینه‌ها.",
      quick_search: "جستجوی پرواز",
      origin: "مبدأ (کابل، هرات...)",
      destination: "مقصد",
    },
    visa: {
      iran: { name: "ایران", docs: "پاسپورت، ۲ قطعه عکس، تذکره الکترونیکی" },
      pakistan: { name: "پاکستان", docs: "پاسپورت، تذکره، اسکن عکس" },
      turkey: { name: "ترکیه", docs: "پاسپورت، حساب بانکی، عکس بیومتریک، سند ملک" },
      russia: { name: "روسیه", docs: "پاسپورت، دعوت‌نامه رسمی، عکس" }
    },
    scholarship: {
      smart_title: "مشاوره هوشمند بورسیه",
      gpa: "معدل (از ۴ یا ۱۰۰)",
      major: "رشته تحصیلی",
      result_btn: "بررسی شانس قبولی"
    },
    cargo: {
      estimate: "تخمین هزینه کارگو",
      weight: "وزن (کیلوگرم)",
      type: "نوع کالا",
      calculate: "محاسبه هزینه"
    },
    status: { pending: "در حال بررسی", approved: "تایید شده (آماده)", rejected: "رد شده", processing: "در حال طی مراحل" },
    common: { submit: "ثبت درخواست", phone: "شماره تماس", name: "نام کامل", tracking_code: "کد پیگیری", whatsapp: "مشاوره واتس‌اپ" }
  },
  ps: {
    title: "بهشتی ټراول اجنسي",
    subtitle: "په کابل کې د سفر او تحصیلي خدمتونو معتبره اداره",
    nav: { home: "اصلي پاڼه", visa: "د هیوادونو ویزې", tickets: "ټکټ ریزرو", scholarship: "بورسونه", cargo: "کارګو", tracking: "تعقیب", admin: "مدیریت" },
    home: {
      hero_title: "باخبره سفر، روښانه راتلونکی",
      hero_sub: "له کابل څخه د نړۍ تر ټولو لیرې نقطو پورې، موږ ستاسو ملګري یو.",
      why_us: "ولې بهشتي ټراول؟",
      why_desc: "د امنیت تضمین، د ویزو په صدور کې سرعت او په لګښتونو کې شفافیت.",
      quick_search: "د الوتنې لټون",
      origin: "مبدأ",
      destination: "مقصد",
    },
    visa: {
      iran: { name: "ایران", docs: "پاسپورټ، ۲ عکسونه، برېښنايي تذکره" },
      pakistan: { name: "پاکستان", docs: "پاسپورټ، تذکره، د عکس سکین" },
      turkey: { name: "ترکیه", docs: "پاسپورټ، بانکي حساب، بیومټریک عکس" },
      russia: { name: "روسیه", docs: "پاسپورټ، رسمي بلنه، عکس" }
    },
    scholarship: {
      smart_title: "د بورسونو هوښیاره مشوره",
      gpa: "معدل (له ۴ یا ۱۰۰ څخه)",
      major: "تحصیلي څانګه",
      result_btn: "د چانس ارزونه"
    },
    cargo: {
      estimate: "د کارګو لګښت اټکل",
      weight: "وزن (کیلوګرام)",
      type: "د مال نوعیت",
      calculate: "د لګښت محاسبه"
    },
    status: { pending: "د ارزونې لاندې", approved: "تایید شوی", rejected: "رد شوی", processing: "د کار لاندې" },
    common: { submit: "غوښتنه ثبتول", phone: "د اړیکې شمیره", name: "بشپړ نوم", tracking_code: "د تعقیب کوډ", whatsapp: "واټس‌اپ مشوره" }
  }
};