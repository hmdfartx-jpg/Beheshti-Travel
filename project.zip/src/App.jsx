import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, signInAnonymously } from 'firebase/auth';
import { auth } from './lib/firebase';
import { translations } from './constants/translations';

// Components
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';

// Pages
import Home from './pages/Home';
import Tickets from './pages/Tickets';
import Visa from './pages/Visa';
import Scholarship from './pages/Scholarship';
import Cargo from './pages/Cargo';
import Tracking from './pages/Tracking';
import Admin from './pages/Admin';

export default function App() {
  const [lang, setLang] = useState('dr');
  const [page, setPage] = useState('home');
  const [user, setUser] = useState(null);
  
  // متغیری برای انتقال اطلاعات جستجو از خانه به صفحه بلیط
  const [ticketSearchData, setTicketSearchData] = useState(null);

  const t = translations[lang];

  useEffect(() => {
    if (auth) {
      const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
        setUser(currentUser);
      });
      signInAnonymously(auth).catch((err) => console.error("Auth Error:", err));
      return () => unsubscribe();
    }
  }, []);

  // این تابع وقتی دکمه جستجو در صفحه اصلی زده شود اجرا می‌شود
  const handleHomeSearch = (data) => {
    setTicketSearchData(data); // داده‌های فرم را ذخیره می‌کند
    setPage('tickets'); // صفحه را به بلیط تغییر می‌دهد
  };

  return (
    <div className="min-h-screen bg-[#F8FAFB] text-right font-[Vazirmatn] selection:bg-[#058B8C]/20" dir="rtl">
      <Navbar lang={lang} setLang={setLang} page={page} setPage={setPage} t={t} />
      <WhatsAppButton t={t} />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        
        {page === 'home' && <Home t={t} setPage={setPage} lang={lang} onSearch={handleHomeSearch} />}
        
        {page === 'tickets' && <Tickets t={t} setPage={setPage} lang={lang} initialData={ticketSearchData} />}
        
        {page.startsWith('visa') && <Visa t={t} lang={lang} setPage={setPage} />}
        {page === 'scholarship' && <Scholarship t={t} lang={lang} setPage={setPage} />}
        {page === 'cargo' && <Cargo t={t} lang={lang} setPage={setPage} />}
        {page === 'tracking' && <Tracking t={t} lang={lang} />}
        {page === 'admin' && <Admin t={t} user={user} />}
        {page.startsWith('apply-') && <Visa t={t} lang={lang} setPage={setPage} initialMode={page} />}
      </main>

      <Footer t={t} lang={lang} />
    </div>
  );
}