import React, { useState, useEffect, useRef } from 'react';
import { Search, MapPin, ArrowRightLeft, ChevronDown, User, Calendar, Plus, Minus, Check, X, ChevronLeft, ChevronRight, ShieldCheck, Clock, Globe, Plane } from 'lucide-react';
import ServiceCard from '../components/ServiceCard';
import { addDoc, collection } from 'firebase/firestore';
import { db, appId } from '../lib/firebase';

// --- تقویم کامل گوگل (بدون تغییر) ---
const GoogleCalendar = ({ onSelect, onClose, selectedDate, lang }) => {
  const [viewDate, setViewDate] = useState(new Date());
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const months = lang === 'dr' 
    ? ["جنوری", "فبروری", "مارچ", "اپریل", "می", "جون", "جولای", "آگوست", "سپتامبر", "اکتوبر", "نوامبر", "دسامبر"]
    : ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  const weekDays = lang === 'dr' ? ["ش", "ی", "د", "س", "چ", "پ", "ج"] : ["S", "M", "T", "W", "T", "F", "S"];

  const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();
  const getFirstDay = (year, month) => new Date(year, month, 1).getDay();

  const renderMonth = (offset) => {
    const currentView = new Date(viewDate.getFullYear(), viewDate.getMonth() + offset, 1);
    const year = currentView.getFullYear();
    const month = currentView.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDay(year, month);
    const blanks = Array(firstDay).fill(null);
    const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

    return (
      <div className="flex-1 px-4">
        <div className="font-bold text-center mb-4 text-gray-700">{months[month]} {year}</div>
        <div className="grid grid-cols-7 gap-1 text-center mb-2">
          {weekDays.map(d => <span key={d} className="text-xs text-gray-400 font-bold">{d}</span>)}
        </div>
        <div className="grid grid-cols-7 gap-y-2 text-center">
          {blanks.map((_, i) => <div key={`b-${i}`} />)}
          {days.map(d => {
            const thisDayDate = new Date(year, month, d);
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
            const isSelected = selectedDate === dateStr;
            const isPast = thisDayDate < today;
            const price = Math.floor(Math.random() * (300 - 150) + 150);
            
            return (
              <button 
                key={d} 
                type="button"
                disabled={isPast}
                onClick={(e) => { 
                  e.stopPropagation(); 
                  if (!isPast) onSelect(dateStr); 
                }}
                className={`h-10 w-10 mx-auto rounded-full flex flex-col items-center justify-center text-xs transition-all relative
                  ${isSelected ? 'bg-[#1a73e8] text-white shadow-md z-10' : ''}
                  ${!isSelected && !isPast ? 'hover:bg-blue-50 text-gray-700 cursor-pointer' : ''}
                  ${isPast ? 'text-gray-300 cursor-default' : ''} 
                `}
              >
                <span className={`font-bold text-sm ${isPast ? 'line-through decoration-gray-300' : ''}`}>{d}</span>
                {!isSelected && !isPast && (
                  <span className="text-[9px] text-green-600 font-medium">${price}</span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="absolute top-full left-0 mt-2 bg-white rounded-xl shadow-2xl border border-gray-200 p-6 z-50 w-[650px] animate-in fade-in zoom-in-95 hidden md:block" onClick={(e) => e.stopPropagation()}>
       <div className="flex justify-between items-center mb-4">
          <button type="button" onClick={() => setViewDate(new Date(viewDate.setMonth(viewDate.getMonth() - 1)))} className="p-2 hover:bg-gray-100 rounded-full"><ChevronLeft size={20}/></button>
          <button type="button" onClick={() => setViewDate(new Date(viewDate.setMonth(viewDate.getMonth() + 1)))} className="p-2 hover:bg-gray-100 rounded-full"><ChevronRight size={20}/></button>
       </div>
       <div className="flex divide-x divide-gray-100 divide-x-reverse">
          {renderMonth(0)}
          {renderMonth(1)}
       </div>
       <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
          <button type="button" onClick={onClose} className="px-4 py-2 text-gray-500 font-bold text-sm hover:bg-gray-50 rounded-lg">انصراف</button>
       </div>
    </div>
  );
};

export default function Home({ t, setPage, lang, onSearch }) {
  const [searchState, setSearchState] = useState('idle');
  const [bookingLoading, setBookingLoading] = useState(null);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const dropdownRef = useRef(null);

  const localT = {
    dr: {
      round_trip: "رفت و برگشت", one_way: "یک طرفه",
      adults: "بزرگسال", children: "کودک",
      economy: "اکونومی", business: "بیزینس", first: "فرست کلاس",
      from: "مبدا (KBL)", to: "مقصد (DXB)",
      search: "جستجوی پرواز",
      best: "بهترین گزینه", cheapest: "ارزان‌ترین",
      filters: { all: "همه فیلترها", stops: "توقف‌ها", airlines: "ایرلاین‌ها", price: "سقف قیمت", clear: "حذف فیلترها" },
      results_found: "پرواز یافت شد",
      select: "انتخاب",
      stops_txt: "توقف", nonstop: "بدون توقف",
      any_stops: "هر تعداد توقف", only_nonstop: "فقط بدون توقف",
      max_price: "کمتر از", currency: "$",
      select_date: "انتخاب تاریخ", return_date: "تاریخ برگشت"
    },
    ps: {
      round_trip: "تګ راتګ", one_way: "یو طرفه",
      adults: "لویان", children: "ماشومان",
      economy: "اکونومي", business: "بیزنس", first: "لومړۍ درجه",
      from: "له کوم ځای؟ (KBL)", to: "چیرته؟ (DXB)",
      search: "د الوتنې لټون",
      best: "غوره", cheapest: "ارزانه",
      filters: { all: "ټول فیلټرونه", stops: "تمځایونه", airlines: "هوایی شرکتونه", price: "قیمت", clear: "پاک کول" },
      results_found: "الوتنې وموندل شوې",
      select: "ټاکل",
      stops_txt: "تمځای", nonstop: "بغیر له وقفې",
      any_stops: "هر څومره", only_nonstop: "یوازې مستقیم",
      max_price: "له دې کم", currency: "$",
      select_date: "نیټه وټاکئ", return_date: "راستنیدو نیټه"
    }
  };
  const lt = localT[lang];

  // تمام دیتابیس شما (حفظ شده)
  const ALL_FLIGHTS = [
    { id: 1, origin: 'KBL', dest: 'DXB', airline: 'Kam Air', logo: '🟧', flightNo: 'RQ-901', dep: '09:30', arr: '11:30', duration: '2h', stops: 0, price: 224, em: 'Eco' },
    { id: 2, origin: 'KBL', dest: 'DXB', airline: 'Fly Dubai', logo: '⬜', flightNo: 'FZ-101', dep: '18:45', arr: '22:00', duration: '3h 15m', stops: 1, price: 340, em: 'High' },
    { id: 3, origin: 'KBL', dest: 'DXB', airline: 'Ariana', logo: '🟦', flightNo: 'FG-332', dep: '13:00', arr: '14:15', duration: '1h 15m', stops: 0, price: 180, em: 'Avg' },
    { id: 4, origin: 'KBL', dest: 'IKA', airline: 'Mahan Air', logo: '🟩', flightNo: 'W5-112', dep: '10:00', arr: '12:30', duration: '2h 30m', stops: 0, price: 200, em: 'Avg' },
    { id: 5, origin: 'KBL', dest: 'IKA', airline: 'Ariana', logo: '🟦', flightNo: 'FG-440', dep: '15:00', arr: '17:30', duration: '2h 30m', stops: 0, price: 190, em: 'Eco' },
    { id: 6, origin: 'KBL', dest: 'IKA', airline: 'Kish Air', logo: '🟥', flightNo: 'Y9-700', dep: '08:00', arr: '11:00', duration: '3h', stops: 1, price: 150, em: 'High' },
    { id: 7, origin: 'KBL', dest: 'IST', airline: 'Turkish', logo: '🔴', flightNo: 'TK-707', dep: '08:00', arr: '14:00', duration: '6h', stops: 0, price: 650, em: 'Avg' },
    { id: 8, origin: 'KBL', dest: 'IST', airline: 'Kam Air', logo: '🟧', flightNo: 'RQ-555', dep: '10:00', arr: '17:00', duration: '7h', stops: 1, price: 450, em: 'High' },
  ];

  const [formData, setFormData] = useState({
    origin: '', 
    destination: '', 
    date: '', 
    returnDate: '',
    tripType: 'round_trip', 
    flightClass: 'economy',
    adults: 1, 
    children: 0
  });

  const [results, setResults] = useState([]);
  const [filteredResults, setFilteredResults] = useState([]);
  const [filters, setFilters] = useState({ stops: 'any', price: 1000, airlines: [] });

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setActiveDropdown(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (!formData.origin && !formData.destination) {
       alert(lang === 'dr' ? "لطفا مبدا یا مقصد را وارد کنید" : "مهربانی وکړئ مبدا یا مقصد دننه کړئ");
       return;
    }
    
    // اگر تابع onSearch وجود دارد (از App.jsx پاس داده شده)، به صفحه بلیط برو
    if (onSearch) {
        onSearch(formData);
    } else {
        // این بخش اجرا نمی‌شود ولی برای اطمینان و حفظ کد، باقی مانده است
        setSearchState('loading');
        setTimeout(() => {
          const found = ALL_FLIGHTS.filter(f => 
            (f.origin.toLowerCase().includes(formData.origin.toLowerCase()) || formData.origin === '') &&
            (f.dest.toLowerCase().includes(formData.destination.toLowerCase()) || formData.destination === '')
          );
          setResults(found);
          setFilteredResults(found);
          setSearchState(found.length > 0 ? 'results' : 'empty');
        }, 800);
    }
  };

  const toggleAirlineFilter = (airlineName) => {
    setFilters(prev => {
      const exists = prev.airlines.includes(airlineName);
      if (exists) return { ...prev, airlines: prev.airlines.filter(a => a !== airlineName) };
      return { ...prev, airlines: [...prev.airlines, airlineName] };
    });
  };

  const handleBook = async (flight) => {
    const customerName = prompt(lang === 'dr' ? "نام کامل:" : "بشپړ نوم:");
    const customerPhone = prompt(lang === 'dr' ? "شماره تماس:" : "د اړیکې شمیره:");
    if (!customerName || !customerPhone) return;

    setBookingLoading(flight.id);
    const requestData = {
      name: customerName, phone: customerPhone,
      type: 'flight_ticket',
      details: `${flight.airline} | ${flight.origin}-${flight.dest} | ${formData.date}`,
      price: flight.price,
      status: 'pending',
      timestamp: Date.now(),
      trackingCode: Math.random().toString(36).substring(7).toUpperCase()
    };
    try {
      await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'requests'), requestData);
      setPage('tracking');
    } catch (err) { console.error(err); }
    setBookingLoading(null);
  };

  const TopFilterBtn = ({ label, active, onClick, icon: Icon }) => (
    <button 
      type="button" 
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold transition-all relative ${active ? 'bg-white text-[#1e3a8a]' : 'bg-white/10 text-white hover:bg-white/20'}`}
    >
      {Icon && <Icon size={16}/>} {label} <ChevronDown size={14} className={active ? 'rotate-180 transition-transform' : ''}/>
    </button>
  );

  const ResultFilterChip = ({ label, icon: Icon, onClick, active, valueLabel }) => (
    <button onClick={onClick} className={`flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-bold transition-colors whitespace-nowrap ${active ? 'bg-blue-50 border-[#1e3a8a] text-[#1e3a8a]' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`}>
      {Icon && <Icon size={16}/>} {label} {valueLabel && <span className="ml-1 text-[#1e3a8a] bg-blue-100 px-1.5 rounded text-xs">{valueLabel}</span>} <ChevronDown size={14} className="text-gray-500"/>
    </button>
  );

  return (
    <div className="space-y-24 animate-in fade-in duration-700 pb-20 font-[Vazirmatn]">
      
      {/* --- بخش Hero --- */}
      <div className="relative">
        <div className="h-[400px] md:h-[500px] rounded-[3rem] overflow-hidden shadow-xl relative z-0">
          <div className="absolute inset-0 bg-gradient-to-t from-[#1e3a8a]/90 via-transparent to-transparent z-10" />
          <img src="https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=2074&auto=format&fit=crop" className="w-full h-full object-cover" alt="Travel" />
          <div className="absolute top-1/3 right-10 z-20 text-white max-w-2xl">
             <h2 className="text-5xl font-black mb-4 drop-shadow-lg leading-tight">{t.home.hero_title}</h2>
             <p className="text-xl font-medium drop-shadow-md opacity-90">{t.home.hero_sub}</p>
          </div>
        </div>

        {/* --- نوار جستجو --- */}
        <div className="max-w-6xl mx-auto px-4 relative z-30 -mt-24">
          <div className="bg-[#1e3a8a] p-6 rounded-[2rem] shadow-2xl border border-white/10 space-y-6" ref={dropdownRef}>
            
            <div className="flex flex-wrap items-center gap-3 relative z-50">
               <div className="relative">
                  <TopFilterBtn label={lt[formData.tripType]} icon={ArrowRightLeft} active={activeDropdown === 'type'} onClick={() => setActiveDropdown(activeDropdown === 'type' ? null : 'type')} />
                  {activeDropdown === 'type' && (
                    <div className="absolute top-full right-0 mt-2 w-48 bg-white rounded-xl shadow-xl py-2 overflow-hidden animate-in zoom-in-95">
                      {['round_trip', 'one_way'].map(k => (
                        <button key={k} onClick={() => {setFormData({...formData, tripType: k}); setActiveDropdown(null)}} className="w-full text-right px-4 py-3 hover:bg-gray-50 text-sm font-bold text-gray-700 flex justify-between">{lt[k]} {formData.tripType === k && <Check size={16} className="text-[#1e3a8a]"/>}</button>
                      ))}
                    </div>
                  )}
               </div>
               
               <div className="relative">
                  <TopFilterBtn label={`${formData.adults + formData.children} ${lang === 'dr' ? 'مسافر' : 'مسافر'}`} icon={User} active={activeDropdown === 'pax'} onClick={() => setActiveDropdown(activeDropdown === 'pax' ? null : 'pax')} />
                  {activeDropdown === 'pax' && (
                    <div className="absolute top-full right-0 mt-2 w-72 bg-white rounded-xl shadow-xl p-4 animate-in zoom-in-95 cursor-default">
                       {['adults', 'children'].map(k => (
                         <div key={k} className="flex justify-between items-center mb-4 last:mb-0">
                           <span className="font-bold text-gray-700">{lt[k]}</span>
                           <div className="flex items-center gap-3 bg-gray-100 rounded-lg p-1">
                             <button onClick={() => setFormData(p => ({...p, [k]: Math.max(0, p[k]-1)}))} className="w-8 h-8 flex items-center justify-center bg-white rounded shadow text-gray-600 hover:text-red-500"><Minus size={14}/></button>
                             <span className="w-4 text-center font-bold text-sm">{formData[k]}</span>
                             <button onClick={() => setFormData(p => ({...p, [k]: p[k]+1}))} className="w-8 h-8 flex items-center justify-center bg-[#1e3a8a] text-white rounded shadow"><Plus size={14}/></button>
                           </div>
                         </div>
                       ))}
                       <button onClick={() => setActiveDropdown(null)} className="w-full mt-2 py-2 text-[#1e3a8a] font-black text-sm hover:bg-blue-50 rounded-lg">تایید</button>
                    </div>
                  )}
               </div>

               <div className="relative">
                  <TopFilterBtn label={lt[formData.flightClass]} active={activeDropdown === 'class'} onClick={() => setActiveDropdown(activeDropdown === 'class' ? null : 'class')} />
                  {activeDropdown === 'class' && (
                    <div className="absolute top-full right-0 mt-2 w-48 bg-white rounded-xl shadow-xl py-2 overflow-hidden animate-in zoom-in-95">
                      {['economy', 'business', 'first'].map(k => (
                        <button key={k} onClick={() => {setFormData({...formData, flightClass: k}); setActiveDropdown(null)}} className="w-full text-right px-4 py-3 hover:bg-gray-50 text-sm font-bold text-gray-700 flex justify-between">{lt[k]} {formData.flightClass === k && <Check size={16} className="text-[#1e3a8a]"/>}</button>
                      ))}
                    </div>
                  )}
               </div>
            </div>

            <form onSubmit={handleSearch} className="bg-white rounded-[1.5rem] p-2 flex flex-col lg:flex-row shadow-lg divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-gray-100 relative z-30">
               <div className="flex-1 px-4 py-3 flex items-center gap-3 hover:bg-gray-50 rounded-xl transition cursor-pointer group">
                  <div className="text-gray-400 group-hover:text-[#1e3a8a] transition"><Plane size={20}/></div>
                  <input name="origin" value={formData.origin} onChange={e => setFormData({...formData, origin: e.target.value})} placeholder={lt.from} className="w-full text-sm font-black text-gray-800 bg-transparent outline-none placeholder:font-normal placeholder:text-gray-400" />
               </div>

               <div className="flex items-center justify-center -my-3 lg:my-0 lg:-mx-3 z-10">
                 <button type="button" onClick={() => setFormData(p => ({...p, origin: p.destination, destination: p.origin}))} className="bg-gray-100 p-2 rounded-full text-gray-500 hover:bg-[#1e3a8a] hover:text-white transition shadow-sm border border-white"><ArrowRightLeft size={16} /></button>
               </div>

               <div className="flex-1 px-4 py-3 flex items-center gap-3 hover:bg-gray-50 rounded-xl transition cursor-pointer group">
                  <div className="text-gray-400 group-hover:text-[#1e3a8a] transition"><MapPin size={20}/></div>
                  <input name="destination" value={formData.destination} onChange={e => setFormData({...formData, destination: e.target.value})} placeholder={lt.to} className="w-full text-sm font-black text-gray-800 bg-transparent outline-none placeholder:font-normal placeholder:text-gray-400" />
               </div>

               <div className="flex-1 relative border-r border-gray-100">
                  <div onClick={() => setActiveDropdown(activeDropdown === 'date_dep' ? null : 'date_dep')} className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 rounded-xl transition cursor-pointer group h-full">
                     <Calendar size={20} className="text-gray-400 group-hover:text-[#1e3a8a]"/>
                     <div className="flex flex-col">
                        <span className="text-[10px] text-gray-400 font-bold">{lt.select_date}</span>
                        <span className={`text-sm font-black ${formData.date ? 'text-gray-800' : 'text-gray-300'}`}>{formData.date || '---'}</span>
                     </div>
                  </div>
                  {activeDropdown === 'date_dep' && <GoogleCalendar lang={lang} selectedDate={formData.date} onSelect={(d) => { setFormData({...formData, date: d}); setActiveDropdown(null); }} onClose={() => setActiveDropdown(null)} />}
               </div>

               <div className="flex-1 relative border-r border-gray-100">
                  <div onClick={() => formData.tripType === 'round_trip' && setActiveDropdown(activeDropdown === 'date_ret' ? null : 'date_ret')} className={`flex items-center gap-3 px-4 py-3 rounded-xl transition h-full ${formData.tripType === 'round_trip' ? 'hover:bg-gray-50 cursor-pointer group' : 'bg-gray-50 opacity-50 cursor-not-allowed'}`}>
                     <Calendar size={20} className="text-gray-400 group-hover:text-[#1e3a8a]"/>
                     <div className="flex flex-col">
                        <span className="text-[10px] text-gray-400 font-bold">{lt.return_date}</span>
                        <span className={`text-sm font-black ${formData.returnDate ? 'text-gray-800' : 'text-gray-300'}`}>{formData.returnDate || '---'}</span>
                     </div>
                  </div>
                  {activeDropdown === 'date_ret' && <GoogleCalendar lang={lang} selectedDate={formData.returnDate} onSelect={(d) => { setFormData({...formData, returnDate: d}); setActiveDropdown(null); }} onClose={() => setActiveDropdown(null)} />}
               </div>

               <div className="p-2">
                 <button type="submit" className="w-full lg:w-auto h-full min-w-[140px] bg-[#f97316] hover:bg-[#ea580c] text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-orange-200 transition-all transform active:scale-95 py-3 lg:py-0">
                    {searchState === 'loading' ? <span className="animate-spin">⏳</span> : <Search size={22}/>} {lt.search}
                 </button>
               </div>
            </form>
          </div>
        </div>
      </div>

      {/* --- بخش سرویس‌ها --- */}
      {searchState === 'idle' && (
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-center mt-10">
          <ServiceCard icon={ShieldCheck} title={lang === 'dr' ? "امنیت و اعتماد" : "امنیت او باور"} desc={t.home.why_desc} color='#1e3a8a' />
          <ServiceCard icon={Clock} title={lang === 'dr' ? "سرعت در اجرا" : "په کار کې چټکتیا"} desc={t.home.why_desc} color='#f97316' />
          <ServiceCard icon={Globe} title={lang === 'dr' ? "پوشش جهانی" : "نړیوال پوښښ"} desc={t.home.why_desc} color='#1e3a8a' />
        </div>
      )}
    </div>
  );
}