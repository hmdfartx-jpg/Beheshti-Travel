import React, { useState, useEffect, useRef } from 'react';
import { Search, MapPin, ArrowRightLeft, ChevronDown, User, Calendar, Plus, Minus, Check, SlidersHorizontal, X, ChevronLeft, ChevronRight, Plane } from 'lucide-react';
import { addDoc, collection } from 'firebase/firestore';
import { db, appId } from '../lib/firebase';

const GoogleCalendar = ({ onSelect, onClose, selectedDate, lang }) => {
  const [viewDate, setViewDate] = useState(new Date());
  const today = new Date(); today.setHours(0, 0, 0, 0);

  const months = lang === 'dr' 
    ? ["جنوری", "فبروری", "مارچ", "اپریل", "می", "جون", "جولای", "آگوست", "سپتامبر", "اکتوبر", "نوامبر", "دسامبر"]
    : ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();
  const getFirstDay = (year, month) => new Date(year, month, 1).getDay();

  const renderMonth = (offset) => {
    const currentView = new Date(viewDate.getFullYear(), viewDate.getMonth() + offset, 1);
    const year = currentView.getFullYear();
    const month = currentView.getMonth();
    const days = Array.from({ length: getDaysInMonth(year, month) }, (_, i) => i + 1);
    const blanks = Array(getFirstDay(year, month)).fill(null);

    return (
      <div className="flex-1 px-4">
        <div className="font-bold text-center mb-4 text-gray-700">{months[month]} {year}</div>
        <div className="grid grid-cols-7 gap-y-2 text-center">
          {blanks.map((_, i) => <div key={`b-${i}`} />)}
          {days.map(d => {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
            const isSelected = selectedDate === dateStr;
            const isPast = new Date(year, month, d) < today;
            const price = Math.floor(Math.random() * (300 - 150) + 150);
            return (
              <button key={d} type="button" disabled={isPast} onClick={(e) => { e.stopPropagation(); if (!isPast) onSelect(dateStr); }}
                className={`h-10 w-10 mx-auto rounded-full flex flex-col items-center justify-center text-xs relative ${isSelected ? 'bg-[#1a73e8] text-white shadow-md' : ''} ${!isSelected && !isPast ? 'hover:bg-blue-50 text-gray-700' : ''} ${isPast ? 'text-gray-300' : ''}`}>
                <span className="font-bold">{d}</span>
                {!isSelected && !isPast && <span className="text-[9px] text-green-600">${price}</span>}
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="absolute top-full right-0 mt-2 bg-white rounded-xl shadow-2xl border border-gray-200 p-6 z-50 w-[650px] animate-in fade-in zoom-in-95 hidden md:flex" onClick={(e) => e.stopPropagation()}>
       <div className="flex-1 flex divide-x divide-gray-100 divide-x-reverse">{renderMonth(0)}{renderMonth(1)}</div>
       <button onClick={onClose} className="absolute bottom-4 left-4 px-4 py-2 bg-gray-100 rounded-lg text-sm font-bold">بستن</button>
    </div>
  );
};

export default function Tickets({ t, setPage, lang, initialData }) {
  const [searchState, setSearchState] = useState('idle');
  const [bookingLoading, setBookingLoading] = useState(null);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const dropdownRef = useRef(null);

  const [formData, setFormData] = useState({
    origin: '', destination: '', date: '', returnDate: '',
    tripType: 'round_trip', flightClass: 'economy', adults: 1, children: 0
  });

  const [results, setResults] = useState([]);
  const [filteredResults, setFilteredResults] = useState([]);
  const [filters, setFilters] = useState({ stops: 'any', price: 1000, airlines: [] });

  const ALL_FLIGHTS = [
    { id: 1, origin: 'KBL', dest: 'DXB', airline: 'Kam Air', logo: '🟧', dep: '09:30', arr: '11:30', duration: '2h', stops: 0, price: 224, em: 'Eco' },
    { id: 2, origin: 'KBL', dest: 'DXB', airline: 'Fly Dubai', logo: '⬜', dep: '18:45', arr: '22:00', duration: '3h 15m', stops: 1, price: 340, em: 'High' },
    { id: 3, origin: 'KBL', dest: 'DXB', airline: 'Ariana', logo: '🟦', dep: '13:00', arr: '14:15', duration: '1h 15m', stops: 0, price: 180, em: 'Avg' },
    { id: 4, origin: 'KBL', dest: 'IKA', airline: 'Mahan Air', logo: '🟩', dep: '10:00', arr: '12:30', duration: '2h 30m', stops: 0, price: 200, em: 'Avg' },
    { id: 5, origin: 'KBL', dest: 'IKA', airline: 'Ariana', logo: '🟦', dep: '15:00', arr: '17:30', duration: '2h 30m', stops: 0, price: 190, em: 'Eco' },
  ];

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
      performSearch(initialData);
    } else {
        performSearch(formData); 
    }
  }, [initialData]);

  const performSearch = (data) => {
    setSearchState('loading');
    setTimeout(() => {
      const found = ALL_FLIGHTS.filter(f => 
        (f.origin.toLowerCase().includes((data.origin || '').toLowerCase()) || data.origin === '') &&
        (f.dest.toLowerCase().includes((data.destination || '').toLowerCase()) || data.destination === '')
      );
      setResults(found);
      setFilteredResults(found);
      setSearchState(found.length > 0 ? 'results' : 'empty');
    }, 800);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    performSearch(formData);
  };

  const handleBook = async (flight) => {
     const customerName = prompt("نام کامل:");
     const customerPhone = prompt("شماره تماس:");
     if(!customerName) return;
     
     setBookingLoading(flight.id);
     const requestData = {
        name: customerName, phone: customerPhone,
        type: 'flight_ticket',
        details: `${flight.airline} | ${flight.origin}-${flight.dest}`,
        price: flight.price,
        status: 'pending',
        timestamp: Date.now(),
        trackingCode: Math.random().toString(36).substring(7).toUpperCase()
     };
     try {
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'requests'), requestData);
        alert("درخواست رزرو ثبت شد. کد: " + requestData.trackingCode);
        setPage('tracking');
     } catch(e) { console.error(e); }
     setBookingLoading(null);
  };

  const TopFilterBtn = ({ label, active, onClick, icon: Icon }) => (
    <button type="button" onClick={onClick} className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold transition-all relative ${active ? 'bg-white text-[#1e3a8a] border border-gray-200' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
      {Icon && <Icon size={16}/>} {label} <ChevronDown size={14}/>
    </button>
  );

  return (
    <div className="space-y-8 animate-in fade-in font-[Vazirmatn]">
       <div className="bg-white p-6 rounded-[2rem] shadow-xl border border-gray-100 space-y-6 relative z-30">
          <div className="flex flex-wrap gap-3 relative z-50">
             <div className="relative">
                <TopFilterBtn label={formData.tripType === 'round_trip' ? 'رفت و برگشت' : 'یک طرفه'} icon={ArrowRightLeft} active={activeDropdown === 'type'} onClick={() => setActiveDropdown(activeDropdown === 'type' ? null : 'type')} />
             </div>
          </div>

          <form onSubmit={handleSearch} className="bg-white border border-gray-300 rounded-[1.5rem] p-2 flex flex-col lg:flex-row shadow-sm divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-gray-100 relative z-30">
             <div className="flex-1 px-4 py-3 flex items-center gap-3">
                <Plane size={20} className="text-gray-400"/>
                <input value={formData.origin} onChange={e=>setFormData({...formData, origin: e.target.value})} placeholder="مبدا (KBL)" className="w-full text-sm font-black outline-none bg-transparent"/>
             </div>
             <div className="flex-1 px-4 py-3 flex items-center gap-3">
                <MapPin size={20} className="text-gray-400"/>
                <input value={formData.destination} onChange={e=>setFormData({...formData, destination: e.target.value})} placeholder="مقصد (DXB)" className="w-full text-sm font-black outline-none bg-transparent"/>
             </div>
             <div className="flex-1 relative border-r border-gray-100">
                <div onClick={()=>setActiveDropdown(activeDropdown==='date'?null:'date')} className="flex items-center gap-3 px-4 py-3 cursor-pointer">
                   <Calendar size={20} className="text-gray-400"/>
                   <span className={`text-sm font-black ${formData.date?'text-gray-800':'text-gray-300'}`}>{formData.date || 'تاریخ رفت'}</span>
                </div>
                {activeDropdown==='date' && <GoogleCalendar lang={lang} selectedDate={formData.date} onSelect={(d)=>{setFormData({...formData, date:d});setActiveDropdown(null)}} onClose={()=>setActiveDropdown(null)} />}
             </div>
             <div className="p-2">
                <button className="w-full h-full bg-[#f97316] text-white rounded-xl font-bold px-8 py-3 flex items-center justify-center gap-2">
                   {searchState==='loading' ? '...' : <><Search size={20}/> جستجو</>}
                </button>
             </div>
          </form>
       </div>

       {searchState === 'results' && (
          <div className="space-y-4">
             {filteredResults.map(flight => (
                <div key={flight.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 hover:border-[#1e3a8a] transition-all flex flex-col md:flex-row items-center justify-between gap-6">
                   <div className="flex items-center gap-4">
                      <div className="text-2xl">{flight.logo}</div>
                      <div>
                         <div className="font-black text-xl" dir="ltr">{flight.dep} - {flight.arr}</div>
                         <div className="text-xs text-gray-500 font-bold">{flight.airline}</div>
                      </div>
                   </div>
                   <div className="font-black text-2xl text-[#1e3a8a]">${flight.price}</div>
                   <button onClick={()=>handleBook(flight)} className="px-6 py-2 border-2 border-[#1e3a8a] text-[#1e3a8a] rounded-full font-bold hover:bg-[#1e3a8a] hover:text-white transition">انتخاب</button>
                </div>
             ))}
          </div>
       )}
       {searchState === 'empty' && <div className="text-center text-gray-400 py-10">پروازی یافت نشد.</div>}
    </div>
  );
}