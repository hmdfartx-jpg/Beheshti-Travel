import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { CheckCircle, X } from 'lucide-react';
import { db, appId } from '../lib/firebase';

export default function Admin({ user, t }) {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    if (!user) return;
    const q = collection(db, 'artifacts', appId, 'public', 'data', 'requests');
    return onSnapshot(q, (s) => setApplications(s.docs.map(d => ({id: d.id, ...d.data()}))));
  }, [user]);

  if (!user) return <div className="text-center p-10 font-bold text-red-500">دسترسی محدود است. لطفاً وارد شوید.</div>;

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-black text-[#058B8C] border-r-4 border-[#D4AF37] pr-4">پنل مدیریت درخواست‌ها</h2>
      <div className="bg-white rounded-[2rem] border overflow-hidden shadow-sm">
        <table className="w-full text-right">
          <thead className="bg-gray-50 border-b">
            <tr className="text-gray-400 text-xs font-black uppercase">
              <th className="p-6">کد پیگیری</th>
              <th className="p-6">نام مشتری</th>
              <th className="p-6">نوع خدمت</th>
              <th className="p-6">وضعیت</th>
              <th className="p-6">عملیات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {applications.sort((a,b) => b.timestamp - a.timestamp).map(app => (
              <tr key={app.id} className="hover:bg-gray-50 transition-colors">
                <td className="p-6 font-black text-[#D4AF37]">{app.trackingCode}</td>
                <td className="p-6 font-bold">{app.name} <br/><span className="text-xs text-gray-400">{app.phone}</span></td>
                <td className="p-6"><span className="bg-gray-100 px-3 py-1 rounded-lg text-xs font-bold">{app.type}</span></td>
                <td className="p-6">
                  <span className={`px-4 py-2 rounded-xl text-[10px] font-black ${app.status === 'pending' ? 'bg-orange-100 text-orange-600' : 'bg-green-100 text-green-600'}`}>
                    {t.status[app.status] || app.status}
                  </span>
                </td>
                <td className="p-6 flex gap-2">
                  <button onClick={() => updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'requests', app.id), {status: 'approved'})} className="p-2 text-green-600 hover:bg-green-50 rounded-lg"><CheckCircle size={20}/></button>
                  <button onClick={() => updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'requests', app.id), {status: 'rejected'})} className="p-2 text-red-600 hover:bg-red-50 rounded-lg"><X size={20}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}